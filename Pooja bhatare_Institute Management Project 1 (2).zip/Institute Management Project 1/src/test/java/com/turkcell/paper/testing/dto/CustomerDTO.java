package com.turkcell.paper.testing.dto;

public class CustomerDTO {

}
