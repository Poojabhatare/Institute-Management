package com.turkcell.paper.testing.service;

public class CustomerService {

	public Object getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getById(long l) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteById(Object any) {
		// TODO Auto-generated method stub
		
	}

}
