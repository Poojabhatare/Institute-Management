package com.turkcell.paper.testing.service;

public class CustomerRepository {

}
