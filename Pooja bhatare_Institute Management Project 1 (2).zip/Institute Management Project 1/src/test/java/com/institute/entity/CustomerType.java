package com.institute.entity;

public class CustomerType {

	public static final String INDIVIDUAL = null;

}
