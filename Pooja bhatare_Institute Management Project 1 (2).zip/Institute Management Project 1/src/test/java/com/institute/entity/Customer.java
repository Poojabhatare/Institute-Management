package com.institute.entity;

public class Customer {

	public void setId(long l) {
		// TODO Auto-generated method stub
		
	}

	public void setNotificationEmail(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setCustomerType(String individual) {
		// TODO Auto-generated method stub
		
	}

}
