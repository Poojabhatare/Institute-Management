package com.institute.exception;

public class InvalidCustomerRequestException {

}
