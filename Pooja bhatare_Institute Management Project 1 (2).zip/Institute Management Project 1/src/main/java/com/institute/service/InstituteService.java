package com.institute.service;


import java.util.List;

import com.institute.entity.Institute;
import com.institute.model.InstituteDto;
import com.institute.entity.Institute;
import com.institute.model.InstituteDto;
public class InstituteService {
	//Abstract methods
	
		public String createInstitute(Institute institute) {
		return null;
	}
		public InstituteDto updateInstitute(int id,Institute institute) {
			return null;
		}
		public InstituteDto getInstitute(int id) {
			return null;
		}	
		public List<InstituteDto> getAllInstitute() {
			return null;
		}
		public String deleteInstitute(int id) {
			return null;
		}
		public void deleteAllInstitute() {
		}
		public List<InstituteDto> getInstituteByName(String instituteName) {
			return null;
		}
		public List<InstituteDto> getInstituteByBranchName(String branchName) {
			return null;
		}
		public List<InstituteDto> getInstitutebyBranchLocation(String branchLocation) {
			return null;
		}
		
		
		}


