package com.institute.ServiceImpl;

public class AccountDto {

}
