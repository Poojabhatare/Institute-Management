package com.institute.util;

public class Account {

}
