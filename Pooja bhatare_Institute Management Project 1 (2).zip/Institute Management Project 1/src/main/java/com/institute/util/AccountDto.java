package com.institute.util;

public class AccountDto {

}
