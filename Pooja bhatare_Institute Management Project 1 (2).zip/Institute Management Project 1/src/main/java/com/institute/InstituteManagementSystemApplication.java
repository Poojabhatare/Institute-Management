package com.institute;

public class InstituteManagementSystemApplication {

}
