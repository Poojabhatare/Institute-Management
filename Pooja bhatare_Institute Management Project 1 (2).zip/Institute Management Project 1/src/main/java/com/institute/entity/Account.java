package com.institute.entity;

public class Account {

	public Object getAccountType() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAccountType(Object accountType) {
		// TODO Auto-generated method stub
		
	}

	public Object getLocation() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setLocation(Object location) {
		// TODO Auto-generated method stub
		
	}

	public Object getprice() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPrice(Object getprice) {
		// TODO Auto-generated method stub
		
	}

	public Object getPhoneNo() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPhoneNo(Object phoneNo) {
		// TODO Auto-generated method stub
		
	}

	public Object getSetsubjects() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setSubjects(Object setsubjects) {
		// TODO Auto-generated method stub
		
	}

}
