package com.institute.entity;

public class Institute {

	public Object getInstituteName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setInstituteName(Object instituteName) {
		// TODO Auto-generated method stub
		
	}

	public Object getBranchName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setBranchName(Object branchName) {
		// TODO Auto-generated method stub
		
	}

	public Object getIfscCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
