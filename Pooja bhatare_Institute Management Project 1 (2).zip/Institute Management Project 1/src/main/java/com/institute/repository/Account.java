package com.institute.repository;

public class Account {

}
