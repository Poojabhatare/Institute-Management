package com.institute.controller;

public class Account {

}
