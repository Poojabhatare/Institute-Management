package com.institute.controller;

public class AccountDto {

}
